const jQueryConfig = ()=>{
    $(window).on('load', function() {
        console.log('ok siap');
    });
};
export default jQueryConfig;