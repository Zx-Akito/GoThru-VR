import './scss/main.scss';

// ================================== //
// jQuery init Plugin
// ================================== //
import jQueryConfig from './js/jquery-config';
jQueryConfig();

// Import Vue Config
import vueConfig from './js/vue.config';
